Sample configuration files for:
```
SystemD: procd.service
Upstart: procd.conf
OpenRC:  procd.openrc
         procd.openrcconf
CentOS:  procd.init
macOS:    org.proc.procd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
